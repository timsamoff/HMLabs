Cookies.remove('cdTime');
Cookies.remove('firstTime');
Cookies.remove('gameOver');
console.log('Cookies removed.');
window.open ('index.html','_self',false);