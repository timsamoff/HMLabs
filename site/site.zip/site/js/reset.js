localStorage.removeItem('cdTime');
localStorage.removeItem('firstTime');
localStorage.removeItem('gameOver');
console.log('Cookies removed.');
window.open ('index.html','_self',false);